# Icons Directory

Place your FAF logo here in these sizes:
- icon16.png (16x16)
- icon32.png (32x32)
- icon48.png (48x48)
- icon128.png (128x128)

Use the social-logo.svg from /Users/wolfejam/faf-svelte-engine/static/social-logo.svg as the source!